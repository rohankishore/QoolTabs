# QoolTabs

## QTabWidget but with drag and drop, context menu and so on.


## Features in a Glance

- Drag and drop support
- Context menu with one default option to close all tabs
- Support for themes like qdarktheme, etc